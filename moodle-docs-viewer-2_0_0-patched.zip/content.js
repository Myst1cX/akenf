// Supported document extensions for client-side viewing
const VIEWABLE_EXTENSIONS = ['.docx', '.doc', '.pptx', '.ppt', '.xlsx', '.pdf'];
const DEFAULT_MAX_FILE_SIZE = 20; // MB

console.log('[Moodle Docs Viewer] Content script loaded on:', window.location.href);

let extensionEnabled = true;
let maxFileSizeMB = DEFAULT_MAX_FILE_SIZE;

browser.storage.local.get(['enabled', 'maxFileSize']).then((result) => {
  extensionEnabled = result.enabled !== false;
  maxFileSizeMB = result.maxFileSize || DEFAULT_MAX_FILE_SIZE;
});

browser.storage.onChanged.addListener((changes) => {
  if (changes.enabled)     extensionEnabled = changes.enabled.newValue;
  if (changes.maxFileSize) maxFileSizeMB    = changes.maxFileSize.newValue;
});

function isViewableDocument(url) {
  if (!url) return false;
  const low = url.toLowerCase().split('?')[0];
  return VIEWABLE_EXTENSIONS.some(ext => low.endsWith(ext));
}

function isMoodleResource(anchor) {
  return (anchor.href || '').includes('/mod/resource/view.php');
}

function extractFilename(url, contentDisposition) {
  if (contentDisposition) {
    const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
    if (match && match[1]) return match[1].replace(/['"]/g, '');
  }
  const segments = url.split('?')[0].split('/');
  return segments[segments.length - 1] || 'document';
}

function toAbsoluteUrl(url) {
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  if (url.startsWith('//')) return window.location.protocol + url;
  return new URL(url, window.location.href).href;
}

function findAnchorElement(target) {
  let element = target;
  while (element && element !== document.body) {
    if (element.tagName === 'A' && element.href) return element;
    element = element.parentElement;
  }
  return null;
}

function showLoadingState(anchor) {
  const originalStyle = anchor.style.cssText;
  anchor.style.opacity = '0.6';
  anchor.style.cursor = 'wait';
  return () => { anchor.style.cssText = originalStyle; };
}

function showError(message) {
  console.error('[Moodle Docs Viewer]', message);
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed; bottom: 20px; right: 20px; background: #dc3545; color: white;
    padding: 12px 20px; border-radius: 6px; z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); max-width: 400px;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  setTimeout(() => notification.remove(), 5000);
}

/**
 * Detects document type from content-type and URL, now including PDF and images.
 */
function detectDocType(contentType, finalUrl) {
  const ct  = contentType.toLowerCase();
  const url = finalUrl.toLowerCase().split('?')[0];

  if (ct.includes('wordprocessingml') || ct.includes('msword') || url.endsWith('.docx') || url.endsWith('.doc'))
    return url.endsWith('.doc') || ct.includes('msword') ? 'doc' : 'docx';
  if (ct.includes('presentationml') || url.endsWith('.pptx')) return 'pptx';
  if (ct.includes('powerpoint') || ct.includes('vnd.ms-powerpoint') || url.endsWith('.ppt')) return 'ppt';
  if (ct.includes('spreadsheetml') || ct.includes('excel') || url.endsWith('.xlsx')) return 'xlsx';
  if (ct.includes('pdf') || url.endsWith('.pdf')) return 'pdf';
  return null;
}

// ── Inlined doc-store helpers (content scripts can't share window.DocStore) ──

function genDocKey() {
  const rand = Math.random().toString(36).slice(2, 8);
  return `savedDoc_${Date.now()}_0_${rand}`;
}

async function getExpiryMs() {
  const result = await browser.storage.local.get(['expiryMinutes', 'expiryHours']);
  let minutes;
  if (result.expiryMinutes !== undefined && result.expiryMinutes !== null) {
    minutes = result.expiryMinutes;
  } else if (result.expiryHours !== undefined && result.expiryHours !== null) {
    minutes = result.expiryHours * 60;
  } else {
    minutes = 2; // default: 2 minutes
  }
  return minutes * 60 * 1000;
}

/** Inlined IDB putBlob for content-script context (can't use window.DocBlobStore). */
async function idbPutBlob(key, arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let compressed = null;
  let useCompressed = false;

  if (typeof CompressionStream !== 'undefined') {
    try {
      const stream = new CompressionStream('gzip');
      const writer = stream.writable.getWriter();
      await writer.write(bytes);
      await writer.close();

      const chunks = [];
      const reader = stream.readable.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
      }

      compressed = new Blob(chunks);
      useCompressed = compressed.size < bytes.byteLength;
    } catch (error) {
      console.warn('[Moodle Docs Viewer] Compression failed, storing uncompressed blob.', error);
    }
  }

  const blob = useCompressed ? compressed : new Blob([bytes]);

  await new Promise((resolve, reject) => {
    const req = indexedDB.open('MoodleDocsViewerDB', 1);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('blobs')) {
        db.createObjectStore('blobs', { keyPath: 'key' });
      }
    };
    req.onsuccess = (e) => {
      const db = e.target.result;
      const tx = db.transaction('blobs', 'readwrite');
      tx.objectStore('blobs').put({ key, blob, compressed: useCompressed });
      tx.oncomplete = () => resolve();
      tx.onerror    = (ev) => reject(ev.target.error);
    };
    req.onerror = (e) => reject(e.target.error);
  });
}

async function saveDocRecord(key, { arrayBuffer, filename, docType, url, mimeType }) {
  const now = Date.now();
  const expiryMs = await getExpiryMs();
  const expiresAt = expiryMs === 0 ? null : now + expiryMs;

  // Store blob in IndexedDB
  await idbPutBlob(key, arrayBuffer);

  // Store only metadata in storage.local
  await browser.storage.local.set({
    [key]: {
      filename, docType,
      url: url || '',
      mimeType: mimeType || '',
      createdAt: now,
      lastOpenedAt: now,
      pinned: false,
      expiresAt,
    }
  });
}

function normalizeToArrayBuffer(payload) {
  if (payload instanceof ArrayBuffer) return payload;

  if (ArrayBuffer.isView(payload)) {
    return payload.buffer.slice(payload.byteOffset, payload.byteOffset + payload.byteLength);
  }

  if (Array.isArray(payload)) {
    return Uint8Array.from(payload).buffer;
  }

  if (payload && typeof payload === 'object') {
    if (Array.isArray(payload.data)) {
      return Uint8Array.from(payload.data).buffer;
    }

    const length = Number(payload.length);
    if (Number.isInteger(length) && length >= 0) {
      const bytes = new Uint8Array(length);
      for (let i = 0; i < length; i += 1) bytes[i] = payload[i] ?? 0;
      return bytes.buffer;
    }

    const numericKeys = Object.keys(payload).filter(k => /^\d+$/.test(k)).sort((a, b) => Number(a) - Number(b));
    if (numericKeys.length > 0) {
      const bytes = new Uint8Array(numericKeys.length);
      numericKeys.forEach((k, i) => { bytes[i] = payload[k] ?? 0; });
      return bytes.buffer;
    }
  }

  throw new Error('Failed to decode fetched file data. Try downloading the file directly.');
}

async function fetchAndOpenDocument(url, anchor) {
  console.log('[Moodle Docs Viewer] fetchAndOpenDocument:', url);
  const restoreLink = showLoadingState(anchor);

  try {
    const absoluteUrl = toAbsoluteUrl(url);
    const result = await browser.runtime.sendMessage({ type: 'FETCH_DOCUMENT', url: absoluteUrl });

    if (result.error) throw new Error(result.error);

    // Firefox can deserialize typed arrays from extension messages into plain objects.
    // Normalize all known payload shapes into a real ArrayBuffer before further processing.
    result.arrayBuffer = normalizeToArrayBuffer(result.arrayBuffer);

    const docType = detectDocType(result.contentType, result.finalUrl)
                 || detectDocType('', url);

    if (!docType) {
      console.log('[Moodle Docs Viewer] Not a supported document, opening normally.');
      restoreLink();
      window.open(url, '_blank');
      return;
    }

    const maxSizeBytes = maxFileSizeMB * 1024 * 1024;
    if (result.contentLength && parseInt(result.contentLength) > maxSizeBytes) {
      throw new Error(`File too large (${Math.round(parseInt(result.contentLength) / 1024 / 1024)}MB). Maximum size is ${maxFileSizeMB}MB.`);
    }
    if (result.arrayBuffer.byteLength > maxSizeBytes) {
      throw new Error(`File too large (${Math.round(result.arrayBuffer.byteLength / 1024 / 1024)}MB). Maximum size is ${maxFileSizeMB}MB.`);
    }

    const filename = extractFilename(absoluteUrl, result.contentDisposition);

    let mimeType = '';
    if (docType === 'pdf') mimeType = 'application/pdf';

    const docKey = genDocKey();
    await saveDocRecord(docKey, {
      arrayBuffer: result.arrayBuffer,
      filename,
      docType,
      url:      absoluteUrl,
      mimeType,
    });

    const viewerUrl = browser.runtime.getURL('viewer.html') + '?docKey=' + encodeURIComponent(docKey);
    window.open(viewerUrl, '_blank');

  } catch (error) {
    showError(error.message || 'Failed to open document');
    if (confirm('Would you like to download the file normally instead?')) {
      window.open(url, '_blank');
    }
  } finally {
    restoreLink();
  }
}

function interceptDocumentLinks(event) {
  if (!extensionEnabled) return;
  if (event.ctrlKey || event.metaKey || event.shiftKey || event.button !== 0) return;

  const anchor = findAnchorElement(event.target);
  if (!anchor) return;

  const href = anchor.href;
  const isDirectDoc = isViewableDocument(href);
  const isMoodleRes = isMoodleResource(anchor);

  if (!isDirectDoc && !isMoodleRes) return;

  event.preventDefault();
  event.stopPropagation();
  fetchAndOpenDocument(href, anchor);
}

function interceptMiddleClick(event) {
  if (!extensionEnabled || event.button !== 1) return;
  const anchor = findAnchorElement(event.target);
  if (!anchor) return;
  const href = anchor.href;
  if (!isViewableDocument(href) && !isMoodleResource(anchor)) return;
  event.preventDefault();
  event.stopPropagation();
  fetchAndOpenDocument(href, anchor);
}

function markViewableLinks() {
  if (!extensionEnabled) return;
  document.querySelectorAll('a[href]').forEach(link => {
    if (link.dataset.moodleViewerMarked) return;
    if (isViewableDocument(link.href) || isMoodleResource(link)) {
      link.dataset.moodleViewerMarked = 'true';
      link.title = (link.title ? link.title + ' - ' : '') + 'Opens in Document Viewer';
    }
  });
}

document.addEventListener('click', interceptDocumentLinks, true);
document.addEventListener('auxclick', interceptMiddleClick, true);

markViewableLinks();

const observer = new MutationObserver((mutations) => {
  if (mutations.some(m => m.addedNodes.length > 0)) markViewableLinks();
});
observer.observe(document.body, { childList: true, subtree: true });

// Clean up legacy tempDoc* keys on page load (old single-key hand-off scheme)
browser.storage.local.get(null).then((all) => {
  const legacy = Object.keys(all).filter(k => k === 'tempDoc' || k.startsWith('tempDoc_'));
  if (legacy.length > 0) browser.storage.local.remove(legacy);
});
