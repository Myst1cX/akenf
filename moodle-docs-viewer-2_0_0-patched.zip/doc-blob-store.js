/**
 * doc-blob-store.js — IndexedDB-backed blob storage with gzip compression.
 *
 * Exposed as window.DocBlobStore for extension pages (dropzone.html, viewer.html,
 * library.html). background.js and content.js inline a compatible version since
 * they run in service-worker / content-script contexts.
 *
 * Storage schema (IDB object store "blobs", keyPath: "key"):
 *   { key: string, blob: Blob, compressed: boolean }
 *
 * Compression uses native CompressionStream('gzip') — no library needed.
 * Already-compressed formats (docx/pptx/xlsx) often don't compress further,
 * so we store whichever is smaller and record the flag.
 */

(function () {
  'use strict';

  const DB_NAME    = 'MoodleDocsViewerDB';
  const DB_VERSION = 1;
  const STORE_NAME = 'blobs';

  let _db = null;

  /** Opens (and caches) the IDB connection. Returns a Promise<IDBDatabase>. */
  function openDb() {
    if (_db) return Promise.resolve(_db);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'key' });
        }
      };
      req.onsuccess  = (e) => { _db = e.target.result; resolve(_db); };
      req.onerror    = (e) => reject(e.target.error);
    });
  }

  // ── Compression helpers ────────────────────────────────────────────────────

  async function compress(arrayBuffer) {
    const stream = new CompressionStream('gzip');
    const writer = stream.writable.getWriter();
    writer.write(arrayBuffer);
    writer.close();
    const chunks = [];
    const reader = stream.readable.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    return new Blob(chunks);
  }

  async function decompress(blob) {
    const stream = new DecompressionStream('gzip');
    const writer = stream.writable.getWriter();
    writer.write(await blob.arrayBuffer());
    writer.close();
    const chunks = [];
    const reader = stream.readable.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    const totalLength = chunks.reduce((sum, c) => sum + c.byteLength, 0);
    const out = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      out.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return out.buffer;
  }

  // ── Public API ─────────────────────────────────────────────────────────────

  /**
   * Stores an ArrayBuffer under the given key, compressing if it saves space.
   */
  async function putBlob(key, arrayBuffer) {
    const db = await openDb();
    const compressed = await compress(arrayBuffer);
    const useCompressed = compressed.size < arrayBuffer.byteLength;
    const blob = useCompressed ? compressed : new Blob([arrayBuffer]);

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put({ key, blob, compressed: useCompressed });
      tx.oncomplete = () => resolve();
      tx.onerror    = (e) => reject(e.target.error);
    });
  }

  /**
   * Retrieves and decompresses the ArrayBuffer for the given key.
   * Returns null if not found.
   */
  async function getBlob(key) {
    const db = await openDb();
    const record = await new Promise((resolve, reject) => {
      const tx  = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = (e) => resolve(e.target.result || null);
      req.onerror   = (e) => reject(e.target.error);
    });
    if (!record) return null;
    if (record.compressed) {
      return decompress(record.blob);
    }
    return record.blob.arrayBuffer();
  }

  /**
   * Deletes the blob for a single key. No-op if missing.
   */
  async function deleteBlob(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror    = (e) => reject(e.target.error);
    });
  }

  /**
   * Deletes blobs for multiple keys in a single transaction.
   */
  async function deleteBlobs(keys) {
    if (!keys || keys.length === 0) return;
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx    = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      keys.forEach(k => store.delete(k));
      tx.oncomplete = () => resolve();
      tx.onerror    = (e) => reject(e.target.error);
    });
  }

  // ── Expose ─────────────────────────────────────────────────────────────────

  window.DocBlobStore = { openDb, putBlob, getBlob, deleteBlob, deleteBlobs };
})();
