/**
 * doc-store.js — Shared document persistence helpers.
 *
 * Exposed as window.DocStore so extension pages (dropzone.html, viewer.html,
 * library.html) can include it via a plain <script> tag.  background.js and
 * content.js run in service-worker / content-script context where window is
 * unavailable, so they inline equivalent minimal logic directly.
 */

(function () {
  'use strict';

  // ── Key helpers ────────────────────────────────────────────────────────────

  /**
   * Generates a unique storage key for a new document record.
   * Format: savedDoc_<ms>_<index>_<rand6>
   */
  function genDocKey(index) {
    const rand = Math.random().toString(36).slice(2, 8);
    return `savedDoc_${Date.now()}_${index}_${rand}`;
  }

  /**
   * Returns the expiry duration in milliseconds from the stored setting.
   * 0 means "never expire" (for newly-saved unpinned docs when the user chose
   * the "Never" option — they can still be deleted manually from the library).
   *
   * Setting is stored as `expiryMinutes`.
   */
  async function getExpiryMs() {
    const result = await browser.storage.local.get(['expiryMinutes']);
    const minutes = (result.expiryMinutes !== undefined && result.expiryMinutes !== null)
      ? result.expiryMinutes
      : 2; // default: 2 minutes
    return minutes * 60 * 1000;  // 0 minutes → 0 ms (never)
  }

  // ── CRUD ───────────────────────────────────────────────────────────────────

  /**
   * Saves a new document record.
   * @param {string} key  - Storage key from genDocKey()
   * @param {object} opts - { data (ArrayBuffer), filename, docType, url, mimeType? }
   *
   * File bytes go to IndexedDB via DocBlobStore; metadata goes to storage.local.
   */
  async function saveDoc(key, { data, filename, docType, url, mimeType }) {
    const now = Date.now();
    const expiryMs = await getExpiryMs();
    const expiresAt = expiryMs === 0 ? null : now + expiryMs;

    // Store the blob in IndexedDB (gzip-compressed if beneficial)
    await window.DocBlobStore.putBlob(key, data);

    // Store only metadata in storage.local — no data field
    await browser.storage.local.set({
      [key]: {
        filename,
        docType,
        url: url || '',
        mimeType: mimeType || '',
        createdAt: now,
        lastOpenedAt: now,
        pinned: false,
        expiresAt,
        folder: null,
        sortIndex: now,
      }
    });
  }

  /**
   * Updates lastOpenedAt after a successful document load in the viewer.
   * Does NOT reset expiresAt — the expiry clock keeps running from when
   * the document was first saved.
   */
  async function touchDoc(key) {
    try {
      const result = await browser.storage.local.get([key]);
      const doc = result[key];
      if (!doc) return;

      await browser.storage.local.set({
        [key]: Object.assign({}, doc, { lastOpenedAt: Date.now() })
      });
    } catch (e) {
      console.warn('DocStore.touchDoc failed (non-fatal):', e);
    }
  }

  /**
   * Pins or unpins a document.  Pinned → expiresAt = null.
   * Unpinned → expiresAt is recomputed from current time + setting.
   */
  async function setPinned(key, pinned) {
    const result = await browser.storage.local.get([key]);
    const doc = result[key];
    if (!doc) return;

    const now = Date.now();
    let expiresAt = null;
    if (!pinned) {
      const expiryMs = await getExpiryMs();
      expiresAt = expiryMs === 0 ? null : now + expiryMs;
    }

    await browser.storage.local.set({
      [key]: Object.assign({}, doc, { pinned, expiresAt })
    });
  }

  /**
   * Deletes a single document record (metadata + blob).
   */
  async function deleteDoc(key) {
    await Promise.all([
      browser.storage.local.remove([key]),
      window.DocBlobStore.deleteBlob(key).catch(() => {}),
    ]);
  }

  /**
   * Moves a document into a folder, or out of any folder (folder = null).
   * Folder names are trimmed; an empty/whitespace-only name is treated as
   * "no folder" rather than creating a blank-named folder.
   */
  async function setFolder(key, folder) {
    const result = await browser.storage.local.get([key]);
    const doc = result[key];
    if (!doc) return;

    const clean = folder ? String(folder).trim() : '';

    await browser.storage.local.set({
      [key]: Object.assign({}, doc, { folder: clean || null })
    });
  }

  /**
   * Persists a new manual sortIndex for a document (used by library drag-reorder).
   */
  async function setSortIndex(key, sortIndex) {
    const result = await browser.storage.local.get([key]);
    const doc = result[key];
    if (!doc) return;
    await browser.storage.local.set({
      [key]: Object.assign({}, doc, { sortIndex })
    });
  }

  /**
   * Returns all savedDoc_* records sorted by lastOpenedAt descending.
   * Each entry is { key, ...record }.
   */
  async function listDocs() {
    const all = await browser.storage.local.get(null);
    const docs = [];
    for (const [key, val] of Object.entries(all)) {
      if (key.startsWith('savedDoc_') && val && val.filename) {
        docs.push({
          key,
          ...val,
          folder: (typeof val.folder === 'string' && val.folder.trim()) ? val.folder : null,
          sortIndex: typeof val.sortIndex === 'number' ? val.sortIndex : (val.createdAt || 0),
        });
      }
    }
    docs.sort((a, b) => (b.lastOpenedAt || 0) - (a.lastOpenedAt || 0));
    return docs;
  }

  /**
   * Removes all non-pinned records whose expiresAt is in the past.
   */
  async function cleanupExpired() {
    try {
      const all = await browser.storage.local.get(null);
      const now = Date.now();
      const toDelete = Object.entries(all)
        .filter(([key, val]) =>
          key.startsWith('savedDoc_') &&
          val &&
          !val.pinned &&
          val.expiresAt !== null &&
          val.expiresAt !== undefined &&
          val.expiresAt < now
        )
        .map(([key]) => key);

      if (toDelete.length > 0) {
        await browser.storage.local.remove(toDelete);
        await window.DocBlobStore.deleteBlobs(toDelete).catch(() => {});
        console.log(`[DocStore] Cleaned up ${toDelete.length} expired document(s).`);
      }
    } catch (e) {
      console.warn('[DocStore] cleanupExpired failed (non-fatal):', e);
    }
  }

  // ── Expose ─────────────────────────────────────────────────────────────────

  window.DocStore = {
    genDocKey,
    getExpiryMs,
    saveDoc,
    touchDoc,
    setPinned,
    setFolder,
    setSortIndex,
    deleteDoc,
    listDocs,
    cleanupExpired,
  };
})();
