const dropZone   = document.getElementById('drop-zone');
const browseBtn  = document.getElementById('browse-btn');
const fileInput  = document.getElementById('file-input');
const dzStatus   = document.getElementById('dz-status');
const settingsLink = document.getElementById('open-settings-link');
const manageLibraryLink = document.getElementById('manage-library-link');

settingsLink.addEventListener('click', (e) => {
  e.preventDefault();
  browser.runtime.openOptionsPage();
});

manageLibraryLink.addEventListener('click', (e) => {
  e.preventDefault();
  browser.tabs.create({ url: browser.runtime.getURL('library.html') });
});

// All supported types now go through the same openFile() path.
// PDFs and images are stored as raw bytes and opened in viewer.html,
// just like office docs — no more bare blob-tab openNatively() path.
const SUPPORTED = ['.docx', '.doc', '.pptx', '.ppt', '.xlsx'];
const NATIVE_EXTENSIONS = [
  '.pdf',
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.avif'
];
const ALL_SUPPORTED = [...SUPPORTED, ...NATIVE_EXTENSIONS];

function ext(filename) {
  return filename.slice(filename.lastIndexOf('.')).toLowerCase();
}

function docTypeFromExt(e) {
  const map = {
    '.docx': 'docx', '.doc': 'doc',
    '.pptx': 'pptx', '.ppt': 'ppt',
    '.xlsx': 'xlsx',
    '.pdf': 'pdf',
    '.png': 'image', '.jpg': 'image', '.jpeg': 'image',
    '.gif': 'image', '.webp': 'image', '.svg': 'image',
    '.bmp': 'image', '.avif': 'image',
  };
  return map[e] || null;
}

function mimeTypeFromExt(e) {
  const map = {
    '.pdf': 'application/pdf',
    '.png': 'image/png',
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.bmp': 'image/bmp',
    '.avif': 'image/avif',
  };
  return map[e] || 'application/octet-stream';
}

function setStatus(msg, cls = '') {
  dzStatus.textContent = msg;
  dzStatus.className   = cls;
}

// ─── Expiry cleanup ───────────────────────────────────────────────────────────
//
// On every dropzone load, run the shared DocStore expiry sweep to remove
// any savedDoc_* records whose expiry time has passed (and which are unpinned).
// Also migrate any leftover legacy tempDoc / tempDoc_* keys from old versions.

async function cleanupStaleDocKeys() {
  // 1. Expired savedDoc_* records via shared helper
  await DocStore.cleanupExpired();

  // 2. Legacy keys from old extension versions — safe to remove unconditionally,
  //    they were ephemeral hand-off keys under the old model.
  try {
    const all = await browser.storage.local.get(null);
    const legacy = Object.keys(all).filter(k => k === 'tempDoc' || k.startsWith('tempDoc_'));
    if (legacy.length > 0) {
      await browser.storage.local.remove(legacy);
      console.log(`[dropzone] Migrated ${legacy.length} legacy tempDoc key(s).`);
    }
  } catch (e) {
    console.warn('[dropzone] Legacy key cleanup failed (non-fatal):', e);
  }
}

cleanupStaleDocKeys();

// ─── Drag & drop visual feedback ─────────────────────────────────────────────

dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});

['dragleave', 'dragend'].forEach(ev =>
  dropZone.addEventListener(ev, () => dropZone.classList.remove('drag-over'))
);

dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const files = Array.from(e.dataTransfer.files);
  handleFiles(files);
});

// ─── Browse button ────────────────────────────────────────────────────────────

browseBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  fileInput.click();
});

dropZone.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', () => {
  handleFiles(Array.from(fileInput.files));
  fileInput.value = '';
});

// ─── Core handler ─────────────────────────────────────────────────────────────

async function handleFiles(files) {
  // Filter Office lock files
  const lockFiles = files.filter(f => f.name.startsWith('~$'));
  files = files.filter(f => !f.name.startsWith('~$'));

  const toProcess = files.filter(f => ALL_SUPPORTED.includes(ext(f.name)));
  const skipped   = files.filter(f => !ALL_SUPPORTED.includes(ext(f.name)));

  if (toProcess.length === 0) {
    if (lockFiles.length > 0 && skipped.length === 0) {
      setStatus(
        `${lockFiles.length === 1 ? `'${lockFiles[0].name}' is` : `${lockFiles.length} files are`} Office lock file${lockFiles.length > 1 ? 's' : ''}. Close the document${lockFiles.length > 1 ? 's' : ''} in Word/PowerPoint first.`,
        'error'
      );
    } else {
      const skippedNames = skipped.map(f => f.name).join(', ');
      setStatus(
        `Unsupported file type${skipped.length > 1 ? 's' : ''}: ${skippedNames}. Use .docx, .doc, .pptx, .ppt, .xlsx, .pdf, or a common image format.`,
        'error'
      );
    }
    if (lockFiles.length > 0) {
      console.warn(`Lock file(s) ignored: ${lockFiles.map(f => f.name).join(', ')}`);
    }
    return;
  }

  const total    = toProcess.length;
  let succeeded  = 0;
  const failures = [];

  for (let i = 0; i < toProcess.length; i++) {
    const file    = toProcess[i];
    const counter = total > 1 ? ` (${i + 1}/${total})` : '';
    const onStatus = (msg) => setStatus(msg + counter, 'converting');

    onStatus(`Opening ${file.name}…`);

    try {
      await openFile(file, i, onStatus);
      succeeded++;
    } catch (err) {
      console.error(err);
      const raw    = err.message || 'unknown error';
      const reason = raw.startsWith(file.name + ': ') ? raw.slice(file.name.length + 2) : raw;
      failures.push({ name: file.name, reason });
    }
  }

  const lockSuffix    = lockFiles.length > 0
    ? ` ${lockFiles.length} lock file${lockFiles.length > 1 ? 's' : ''} ignored (close in Office first).`
    : '';
  const skippedSuffix = skipped.length > 0
    ? ` ${skipped.length} skipped (unsupported format).`
    : '';
  const suffixes = lockSuffix + skippedSuffix;

  if (failures.length === 0) {
    const openedMsg = succeeded > 1 ? `Opened ${succeeded} files.` : `Opened ${toProcess[0].name}.`;
    setStatus(openedMsg + suffixes, 'success');
  } else if (succeeded === 0) {
    const failList = failures.map(f => `${f.name} (${f.reason})`).join('; ');
    setStatus(
      `Failed to open ${failures.length === 1 ? '' : `all ${failures.length} files`}: ${failList}.${suffixes}`,
      'error'
    );
  } else {
    const failList = failures.map(f => `${f.name} (${f.reason})`).join('; ');
    setStatus(
      `Opened ${succeeded}. Failed: ${failList}.${suffixes}`,
      'error'
    );
  }

  if (lockFiles.length > 0) {
    console.warn(`Lock file(s) ignored: ${lockFiles.map(f => f.name).join(', ')}`);
  }
  if (skipped.length > 0) {
    console.warn(`${skipped.length} dropped file(s) skipped: ${skipped.map(f => f.name).join(', ')}`);
  }

  setTimeout(() => setStatus(''), 4000);
}

/**
 * Reads, optionally converts, persists, and opens a single file in its own
 * viewer tab.  All file types — including PDFs and images — go through this
 * path; openNatively() (bare blob tab) is gone.
 */
async function openFile(file, index, onStatus) {
  const e        = ext(file.name);
  const docType  = docTypeFromExt(e);

  let finalDocType = docType;

  onStatus(`Reading ${file.name}…`);
  let arrayBuffer;
  try {
    arrayBuffer = await file.arrayBuffer();
  } catch (err) {
    throw new Error(`${file.name}: could not read file - ${err.message}`);
  }

  if (docType === 'doc' || docType === 'ppt') {
    const result    = await browser.storage.local.get(['conversionServerUrl']);
    const serverUrl = (result.conversionServerUrl || '').trim().replace(/\/$/, '');

    if (!serverUrl) {
      throw new Error(`${file.name}: needs a conversion server. Configure one in Settings.`);
    }

    onStatus(`Converting ${file.name} via server…`);
    try {
      const resp = await fetch(
        `${serverUrl}/convert?filename=${encodeURIComponent(file.name)}`,
        { method: 'POST', body: new Blob([arrayBuffer]) }
      );
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.error || `Server error ${resp.status}`);
      }
      arrayBuffer  = await resp.arrayBuffer();
      finalDocType = docType === 'doc' ? 'docx' : 'pptx';
    } catch (err) {
      throw new Error(`${file.name}: conversion failed - ${err.message}`);
    }
  }
  // arrayBuffer now holds the final bytes — raw, no number-array conversion

  onStatus(`Saving ${file.name}…`);

  const docKey = DocStore.genDocKey(index);
  const mimeType = (docType === 'pdf' || docType === 'image')
    ? (file.type || mimeTypeFromExt(e))
    : '';

  await DocStore.saveDoc(docKey, {
    data:     arrayBuffer,
    filename: file.name,
    docType:  finalDocType,
    url:      '',
    mimeType,
  });

  const viewerUrl = browser.runtime.getURL('viewer.html') + '?docKey=' + encodeURIComponent(docKey);
  window.open(viewerUrl, '_blank');
}
