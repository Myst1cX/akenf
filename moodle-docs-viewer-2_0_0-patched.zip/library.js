const libEmpty   = document.getElementById('lib-empty');
const libControls = document.getElementById('lib-controls');
const libTable   = document.getElementById('lib-table');
const libTbody   = document.getElementById('lib-tbody');
const libSearch  = document.getElementById('lib-search');
const libTagFilters = document.getElementById('lib-tag-filters');
const openDropzoneBtn = document.getElementById('open-dropzone-btn');
const goDropzoneLink  = document.getElementById('go-dropzone');
const openSettingsLink = document.getElementById('open-settings-link');

openDropzoneBtn.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('dropzone.html') });
});
if (goDropzoneLink) {
  goDropzoneLink.addEventListener('click', (e) => {
    e.preventDefault();
    browser.tabs.create({ url: browser.runtime.getURL('dropzone.html') });
  });
}
openSettingsLink.addEventListener('click', (e) => {
  e.preventDefault();
  browser.runtime.openOptionsPage();
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function typeIcon(docType) {
  return docType || '';
}

function fmtDate(ms) {
  if (!ms) return '-';
  return new Date(ms).toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function fmtDuration(msLeft) {
  const totalMin = Math.ceil(msLeft / 60000);
  if (totalMin < 60) return `${totalMin} min`;
  const hours = Math.floor(totalMin / 60);
  const mins  = totalMin % 60;
  return mins > 0 ? `${hours}h ${mins} min` : `${hours}h`;
}

function fmtExpiry(doc) {
  if (doc.pinned)     return '<span class="badge-pin">★ Pinned</span>';
  if (!doc.expiresAt) return '-';
  const msLeft = doc.expiresAt - Date.now();
  if (msLeft <= 0)    return '<span class="badge-expired">Expired</span>';
  return `<span class="badge-expiry">⏱ ${fmtDuration(msLeft)}</span>`;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ── State ─────────────────────────────────────────────────────────────────────
// allDocs:      full unfiltered list, freshly loaded from storage on each render()
// searchQuery:  free-text filter, matched against filename + folder name
// activeFilter: { type: 'folder', value } | { type: 'filetype', value } | null
//               value === null for the folder filter means "Unfiled" (no folder)
// sortState:    { key, dir } | null  (null = manual/drag order via sortIndex)

let allDocs = [];
let searchQuery = '';
let activeFilter = null;
let sortState = null;

// ── Filtering + sorting (pure functions over allDocs) ──────────────────────────

function getVisibleDocs() {
  let docs = allDocs;

  if (activeFilter) {
    if (activeFilter.type === 'filetype') {
      docs = docs.filter(d => d.docType === activeFilter.value);
    } else if (activeFilter.type === 'folder') {
      docs = activeFilter.value === null
        ? docs.filter(d => !d.folder)
        : docs.filter(d => d.folder && d.folder.toLowerCase() === activeFilter.value.toLowerCase());
    }
  }

  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    docs = docs.filter(d =>
      d.filename.toLowerCase().includes(q) ||
      (d.folder && d.folder.toLowerCase().includes(q))
    );
  }

  docs = docs.slice();
  if (sortState) {
    const { key, dir } = sortState;
    docs.sort((a, b) => {
      let av, bv;
      if (key === 'filename') {
        av = a.filename.toLowerCase(); bv = b.filename.toLowerCase();
      } else if (key === 'folder') {
        av = (a.folder || '').toLowerCase(); bv = (b.folder || '').toLowerCase();
      } else {
        av = a[key] || 0; bv = b[key] || 0;
      }
      if (av < bv) return dir === 'asc' ? -1 : 1;
      if (av > bv) return dir === 'asc' ? 1 : -1;
      return 0;
    });
  } else {
    // Manual order: drag-reordered docs first (by sortIndex desc = most recently
    // moved-to-top first), matching the existing "newest first" feel.
    docs.sort((a, b) => (b.sortIndex || 0) - (a.sortIndex || 0));
  }
  return docs;
}

function allFolders() {
  const set = new Set();
  for (const d of allDocs) if (d.folder) set.add(d.folder);
  return [...set].sort((a, b) => a.localeCompare(b));
}

function allFiletypes() {
  const set = new Set();
  for (const d of allDocs) if (d.docType) set.add(d.docType);
  return [...set].sort();
}

/**
 * Opens every document currently filed in `folder`, each in its own new tab.
 * Confirms first when there are several files, since browsers may flag a
 * burst of tabs.create() calls as a popup-spam pattern.
 */
async function openAllInFolder(folder) {
  const docs = allDocs.filter(d => d.folder && d.folder.toLowerCase() === folder.toLowerCase());
  if (docs.length === 0) return;

  if (docs.length > 3 && !confirm(`Open all ${docs.length} files in "${folder}"? This will open ${docs.length} new tabs.`)) {
    return;
  }

  for (const doc of docs) {
    const viewerUrl = browser.runtime.getURL('viewer.html') + '?docKey=' + encodeURIComponent(doc.key);
    await browser.tabs.create({ url: viewerUrl });
  }
}

// ── Render: filter bar ──────────────────────────────────────────────────────────

function renderFilterBar() {
  const chips = [];

  chips.push(`<button class="tag-chip ${!activeFilter ? 'active' : ''}" data-filter-clear="1">All</button>`);

  for (const ft of allFiletypes()) {
    const active = activeFilter && activeFilter.type === 'filetype' && activeFilter.value === ft;
    chips.push(`<button class="tag-chip filetype-chip ${active ? 'active' : ''}" data-filetype="${escHtml(ft)}">${escHtml(ft)}</button>`);
  }

  const folders = allFolders();
  const hasUnfiled = allDocs.some(d => !d.folder);
  if (folders.length > 0 || hasUnfiled) {
    chips.push('<span class="tag-chip-sep"></span>');
    for (const folder of folders) {
      const active = activeFilter && activeFilter.type === 'folder' && activeFilter.value && activeFilter.value.toLowerCase() === folder.toLowerCase();
      chips.push(`<span class="folder-chip-group">
        <button class="tag-chip folder-chip ${active ? 'active' : ''}" data-folder="${escHtml(folder)}">${escHtml(folder)}</button>
        <button class="folder-open-all" data-folder-open="${escHtml(folder)}" title="Open all files in &quot;${escHtml(folder)}&quot;">⇱</button>
      </span>`);
    }
    if (hasUnfiled && folders.length > 0) {
      const active = activeFilter && activeFilter.type === 'folder' && activeFilter.value === null;
      chips.push(`<button class="tag-chip folder-chip ${active ? 'active' : ''}" data-folder-unfiled="1">Unfiled</button>`);
    }
  }

  libTagFilters.innerHTML = chips.join('');

  libTagFilters.querySelectorAll('[data-filter-clear]').forEach(btn => {
    btn.addEventListener('click', () => { activeFilter = null; renderAll(); });
  });
  libTagFilters.querySelectorAll('[data-filetype]').forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = { type: 'filetype', value: btn.dataset.filetype };
      renderAll();
    });
  });
  libTagFilters.querySelectorAll('[data-folder-open]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation(); // don't also trigger the adjacent filter chip
      openAllInFolder(btn.dataset.folderOpen);
    });
  });
  libTagFilters.querySelectorAll('[data-folder-unfiled]').forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = { type: 'folder', value: null };
      renderAll();
    });
    // Drop a row onto the "Unfiled" chip to clear its folder.
    btn.addEventListener('dragover', (e) => { e.preventDefault(); btn.classList.add('drag-over'); });
    btn.addEventListener('dragleave', () => btn.classList.remove('drag-over'));
    btn.addEventListener('drop', async (e) => {
      e.preventDefault();
      btn.classList.remove('drag-over');
      const key = e.dataTransfer.getData('text/plain');
      if (!key) return;
      await DocStore.setFolder(key, null);
      loadAndRenderAll();
    });
  });
  // Drop a row onto a folder chip to move it into that folder; click to filter by it.
  libTagFilters.querySelectorAll('.folder-chip[data-folder]').forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = { type: 'folder', value: btn.dataset.folder };
      renderAll();
    });
    btn.addEventListener('dragover', (e) => { e.preventDefault(); btn.classList.add('drag-over'); });
    btn.addEventListener('dragleave', () => btn.classList.remove('drag-over'));
    btn.addEventListener('drop', async (e) => {
      e.preventDefault();
      btn.classList.remove('drag-over');
      const key = e.dataTransfer.getData('text/plain');
      if (!key) return;
      await DocStore.setFolder(key, btn.dataset.folder);
      loadAndRenderAll();
    });
  });
}

// ── Render: sort header indicators ──────────────────────────────────────────────

function renderSortHeaders() {
  document.querySelectorAll('#lib-table th.sortable').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    if (sortState && sortState.key === th.dataset.sort) {
      th.classList.add(sortState.dir === 'asc' ? 'sort-asc' : 'sort-desc');
    }
  });
}

document.querySelectorAll('#lib-table th.sortable').forEach(th => {
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    if (sortState && sortState.key === key) {
      sortState = sortState.dir === 'asc' ? { key, dir: 'desc' } : null; // 3rd click -> back to manual order
    } else {
      sortState = { key, dir: 'asc' };
    }
    renderAll();
  });
});

// ── Render: table rows ────────────────────────────────────────────────────────

function renderFolderCell(doc) {
  if (doc.folder) {
    return `<div class="lib-folder-cell">
      <span class="lib-folder-pill">${escHtml(doc.folder)}</span>
      <button class="lib-folder-edit" data-key="${doc.key}" title="Move to a different folder">✎</button>
      <button class="lib-folder-remove" data-key="${doc.key}" title="Remove from folder">×</button>
    </div>`;
  }
  return `<div class="lib-folder-cell">
    <button class="lib-folder-add" data-key="${doc.key}" title="Place in a folder">+ Folder</button>
  </div>`;
}

function renderRows() {
  const docs = getVisibleDocs();

  if (docs.length === 0) {
    libTable.hidden = true;
    libEmpty.hidden = false;
    libTbody.innerHTML = '';
    return;
  }
  libEmpty.hidden = true;
  libTable.hidden = false;

  libTbody.innerHTML = '';
  for (const doc of docs) {
    const tr = document.createElement('tr');
    tr.dataset.key = doc.key;
    tr.draggable = true; // rows are always draggable: onto other rows (manual order) or folder chips (move)

    const viewerUrl = browser.runtime.getURL('viewer.html') + '?docKey=' + encodeURIComponent(doc.key);

    tr.innerHTML = `
      <td class="lib-drag-handle" title="Drag to reorder, or drop on a folder chip above to file it">⠿</td>
      <td class="lib-filename">
        <a href="${viewerUrl}" target="_blank" class="lib-name" title="${escHtml(doc.filename)}">${escHtml(doc.filename)}</a>
      </td>
      <td class="lib-folder">${renderFolderCell(doc)}</td>
      <td class="lib-date">${fmtDate(doc.createdAt)}</td>
      <td class="lib-date">${fmtDate(doc.lastOpenedAt)}</td>
      <td class="lib-expiry">${fmtExpiry(doc)}</td>
      <td class="lib-actions">
        <button class="btn-pin btn-sm ${doc.pinned ? 'active' : ''}" data-key="${doc.key}" title="${doc.pinned ? 'Unpin' : 'Pin'}">
          ${doc.pinned ? '★' : '☆'} ${doc.pinned ? 'Pinned' : 'Pin'}
        </button>
        <button class="btn-delete btn-sm" data-key="${doc.key}" title="Delete">🗑 Delete</button>
      </td>
    `;
    libTbody.appendChild(tr);
  }

  attachRowHandlers();
  attachDragHandlers();
}

function promptForFolder(existing) {
  const name = prompt('Folder name:', existing || '');
  if (name === null) return undefined; // cancelled
  return name.trim(); // '' means "remove from folder"
}

function attachRowHandlers() {
  libTbody.querySelectorAll('.btn-pin').forEach(btn => {
    btn.addEventListener('click', async () => {
      const key = btn.dataset.key;
      const result = await browser.storage.local.get([key]);
      const doc = result[key];
      if (!doc) return;
      await DocStore.setPinned(key, !doc.pinned);
      loadAndRenderAll();
    });
  });

  libTbody.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      const key = btn.dataset.key;
      const result = await browser.storage.local.get([key]);
      const doc = result[key];
      const name = doc ? doc.filename : key;
      if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
      await DocStore.deleteDoc(key);
      loadAndRenderAll();
    });
  });

  libTbody.querySelectorAll('.lib-folder-add, .lib-folder-edit').forEach(btn => {
    btn.addEventListener('click', async () => {
      const key = btn.dataset.key;
      const doc = allDocs.find(d => d.key === key);
      if (!doc) return;
      const name = promptForFolder(doc.folder);
      if (name === undefined) return; // cancelled
      await DocStore.setFolder(key, name || null);
      loadAndRenderAll();
    });
  });

  libTbody.querySelectorAll('.lib-folder-remove').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const key = btn.dataset.key;
      await DocStore.setFolder(key, null);
      loadAndRenderAll();
    });
  });
}

// ── Drag-and-drop reordering / filing ───────────────────────────────────────────
//
// Dragging a row over another row reorders the manual order (sortIndex).
// Dragging a row over a folder chip in the filter bar files it into that folder
// (see renderFilterBar's drop handlers above) — both read the dragged key from
// the same dataTransfer payload set here.

function attachDragHandlers() {
  let dragKey = null;

  libTbody.querySelectorAll('tr').forEach(tr => {
    tr.addEventListener('dragstart', (e) => {
      dragKey = tr.dataset.key;
      tr.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', dragKey);
    });
    tr.addEventListener('dragend', () => {
      tr.classList.remove('dragging');
      libTbody.querySelectorAll('tr').forEach(r => r.classList.remove('drag-over'));
    });
    tr.addEventListener('dragover', (e) => {
      e.preventDefault();
      if (sortState) return; // row-on-row reorder only applies in manual-order mode
      if (tr.dataset.key === dragKey) return;
      tr.classList.add('drag-over');
    });
    tr.addEventListener('dragleave', () => tr.classList.remove('drag-over'));
    tr.addEventListener('drop', async (e) => {
      e.preventDefault();
      tr.classList.remove('drag-over');
      if (sortState) return;
      const targetKey = tr.dataset.key;
      if (!dragKey || dragKey === targetKey) return;
      await reorderByDrag(dragKey, targetKey);
    });
  });
}

/**
 * Moves `dragKey` to just before `targetKey` in the current visible order,
 * then rewrites sortIndex for every visible doc so the new order persists.
 * Uses descending sortIndex (same convention as the default newest-first order).
 */
async function reorderByDrag(dragKey, targetKey) {
  const docs = getVisibleDocs();
  const fromIdx = docs.findIndex(d => d.key === dragKey);
  const toIdx   = docs.findIndex(d => d.key === targetKey);
  if (fromIdx === -1 || toIdx === -1) return;

  const [moved] = docs.splice(fromIdx, 1);
  docs.splice(toIdx, 0, moved);

  // Assign fresh descending sortIndex values across the reordered visible set.
  const base = Date.now();
  await Promise.all(docs.map((d, i) =>
    DocStore.setSortIndex(d.key, base - i)
  ));

  loadAndRenderAll();
}

// ── Search ────────────────────────────────────────────────────────────────────

libSearch.addEventListener('input', () => {
  searchQuery = libSearch.value.trim();
  renderRows(); // search doesn't change available folders/filetypes, no need to rebuild filter bar
});

// ── Top-level render orchestration ──────────────────────────────────────────────

function renderAll() {
  renderFilterBar();
  renderSortHeaders();
  renderRows();
}

async function loadAndRenderAll() {
  allDocs = await DocStore.listDocs();

  if (allDocs.length === 0) {
    libEmpty.hidden = false;
    libControls.hidden = true;
    libTable.hidden = true;
    return;
  }

  libEmpty.hidden = true;
  libControls.hidden = false;
  renderAll();
}

// ── Expiry ticker — refresh displayed times every minute ──────────────────────

setInterval(() => {
  // Re-render rows in place so expiry countdowns stay current.
  // Also remove any docs that have now expired (delete from storage + IDB).
  const now = Date.now();
  const expired = allDocs.filter(d => !d.pinned && d.expiresAt && d.expiresAt < now);
  if (expired.length > 0) {
    Promise.all(expired.map(d => DocStore.deleteDoc(d.key)))
      .then(() => loadAndRenderAll());
  } else {
    renderRows();
  }
}, 60000);

// ── Live updates via storage.onChanged ───────────────────────────────────────

browser.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const hasDocChange = Object.keys(changes).some(k => k.startsWith('savedDoc_'));
  if (hasDocChange) loadAndRenderAll();
});

// ── Init ──────────────────────────────────────────────────────────────────────

loadAndRenderAll();
