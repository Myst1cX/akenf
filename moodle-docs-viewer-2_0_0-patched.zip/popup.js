const toggleEnabled  = document.getElementById('toggle-enabled');
const popupStatus    = document.getElementById('popup-status');
const openOptionsBtn = document.getElementById('open-options');
const openDropzone   = document.getElementById('open-dropzone');
const openLibrary    = document.getElementById('open-library');

async function loadState() {
  const result = await browser.storage.local.get(['enabled']);
  toggleEnabled.checked = result.enabled !== false;
  updateStatusText();
}

function updateStatusText() {
  popupStatus.textContent = toggleEnabled.checked
    ? 'Documents will open in viewer'
    : 'Documents will download normally';
  popupStatus.className = `popup-status ${toggleEnabled.checked ? 'active' : 'inactive'}`;
}

async function saveState() {
  await browser.storage.local.set({ enabled: toggleEnabled.checked });
  updateStatusText();
}

toggleEnabled.addEventListener('change', saveState);

openOptionsBtn.addEventListener('click', () => {
  browser.runtime.openOptionsPage();
});

openDropzone.addEventListener('click', () => {
  const url = browser.runtime.getURL('dropzone.html');
  browser.tabs.create({ url });
});

openLibrary.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('library.html') });
});

loadState();
