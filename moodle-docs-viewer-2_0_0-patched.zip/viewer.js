// DOM elements
const documentTitle = document.getElementById('document-title');
const documentContainer = document.getElementById('document-container');
const loadingIndicator = document.getElementById('loading-indicator');
const errorContainer = document.getElementById('error-container');
const errorMessage = document.getElementById('error-message');
const downloadBtn = document.getElementById('download-btn');
const printBtn = document.getElementById('print-btn');
const downloadFallbackBtn = document.getElementById('download-fallback-btn');
const closeBtn = document.getElementById('close-btn');
const zoomInBtn = document.getElementById('zoom-in-btn');
const zoomOutBtn = document.getElementById('zoom-out-btn');
const zoomResetBtn = document.getElementById('zoom-reset-btn');
const zoomLevelDisplay = document.getElementById('zoom-level');
const sheetTabsBar = document.getElementById('sheet-tabs-bar');
const slideNavBar = document.getElementById('slide-nav-bar');
const prevSlideBtn = document.getElementById('prev-slide-btn');
const nextSlideBtn = document.getElementById('next-slide-btn');
const slideNumberInput = document.getElementById('slide-number-input');
const slideTotalEl = document.getElementById('slide-total');
const pinBtn = document.getElementById('pin-btn');
const expiryStatus = document.getElementById('expiry-status');
const libraryLink = document.getElementById('library-link');

// Store document info for download
let currentDocument = null;
let currentDocKey   = null;

// Zoom state
let currentZoom = 100;
const ZOOM_STEP = 25;
const MIN_ZOOM = 50;
const MAX_ZOOM = 200;

// Slide state (for PPTX)
let slides = [];
let currentSlideIndex = 0;
let pptxSlideNativeSize = null;
let slideScrollObserver = null;
let isProgrammaticSlideScroll = false;

// Blob URL created for PDF/image — revoked on unload
let nativeBlobUrl = null;

// ─── Loading / Error UI ───────────────────────────────────────────────────────

function showLoading() {
  loadingIndicator.hidden = false;
  errorContainer.hidden = true;
  documentContainer.innerHTML = '';
  documentContainer.hidden = false;
  documentContainer.parentElement.classList.remove('pptx-mode');
  const existingWrapper = document.getElementById('pptx-slides-wrapper');
  if (existingWrapper) existingWrapper.remove();
  const existingResult = document.getElementById('pptxjs-result');
  if (existingResult) existingResult.remove();
  const existingPageSize = document.getElementById('pptx-print-page-size');
  if (existingPageSize) existingPageSize.remove();
  slides = [];
  currentSlideIndex = 0;
  pptxSlideNativeSize = null;
  if (slideScrollObserver) {
    slideScrollObserver.disconnect();
    slideScrollObserver = null;
  }
  if (nativeBlobUrl) {
    URL.revokeObjectURL(nativeBlobUrl);
    nativeBlobUrl = null;
  }
}

function hideLoading() {
  loadingIndicator.hidden = true;
}

function showError(message) {
  hideLoading();
  errorContainer.hidden = false;
  errorMessage.textContent = message;
  documentContainer.innerHTML = '';
  documentContainer.hidden = false;
}

// ─── Pin / expiry UI ─────────────────────────────────────────────────────────

function updatePinUI() {
  if (!currentDocument || !pinBtn || !expiryStatus) return;
  const pinned = currentDocument.pinned;
  pinBtn.classList.toggle('pinned', pinned);
  pinBtn.title = pinned ? 'Unpin document (currently saved indefinitely)' : 'Pin document (save indefinitely)';

  if (pinned) {
    expiryStatus.textContent = '★ Pinned';
    expiryStatus.className = 'expiry-status pinned';
  } else if (currentDocument.expiresAt) {
    const msLeft = currentDocument.expiresAt - Date.now();
    if (msLeft <= 0) {
      expiryStatus.textContent = 'Expired';
      expiryStatus.className = 'expiry-status expired';
    } else {
      const totalMin = Math.ceil(msLeft / 60000);
      let dur;
      if (totalMin < 60) {
        dur = `${totalMin} min`;
      } else {
        const hours = Math.floor(totalMin / 60);
        const mins  = totalMin % 60;
        dur = mins > 0 ? `${hours}h ${mins} min` : `${hours}h`;
      }
      expiryStatus.textContent = `⏱ Expires in ${dur}`;
      expiryStatus.className = 'expiry-status';
    }
  } else {
    expiryStatus.textContent = '';
    expiryStatus.className = 'expiry-status';
  }
}

async function togglePin() {
  if (!currentDocKey || !currentDocument) return;
  const newPinned = !currentDocument.pinned;
  await DocStore.setPinned(currentDocKey, newPinned);
  // Reload the record to reflect the stored state accurately
  const result = await browser.storage.local.get([currentDocKey]);
  if (result[currentDocKey]) {
    currentDocument = result[currentDocKey];
    updatePinUI();
  }
}

if (pinBtn) pinBtn.addEventListener('click', togglePin);
if (libraryLink) {
  libraryLink.addEventListener('click', () => {
    browser.tabs.create({ url: browser.runtime.getURL('library.html') });
  });
}

// ─── MIME / download helpers ──────────────────────────────────────────────────

function getMimeType(docType, mimeType) {
  if (mimeType) return mimeType;
  switch (docType) {
    case 'docx': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    case 'doc':  return 'application/msword';
    case 'pptx': return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
    case 'ppt':  return 'application/vnd.ms-powerpoint';
    case 'xlsx': return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'pdf':  return 'application/pdf';
    default:     return 'application/octet-stream';
  }
}

async function downloadOriginalFile() {
  if (!currentDocument || !currentDocKey) {
    alert('No document data available');
    return;
  }
  const arrayBuffer = await DocBlobStore.getBlob(currentDocKey);
  if (!arrayBuffer) {
    alert('No document data available');
    return;
  }
  const blob = new Blob([arrayBuffer], {
    type: getMimeType(currentDocument.docType, currentDocument.mimeType)
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = currentDocument.filename || `document.${currentDocument.docType}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─── Print helpers ────────────────────────────────────────────────────────────

function updatePrintPageSize() {
  let styleEl = document.getElementById('pptx-print-page-size');
  if (!pptxSlideNativeSize) { if (styleEl) styleEl.remove(); return; }
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'pptx-print-page-size';
    document.head.appendChild(styleEl);
  }
  const widthIn = pptxSlideNativeSize.width / 96;
  const heightIn = pptxSlideNativeSize.height / 96;
  styleEl.textContent = `@media print {
    @page { size: ${widthIn.toFixed(3)}in ${heightIn.toFixed(3)}in; margin: 0; }
  }`;
}

function applyPptxPrintScale() {
  if (!pptxSlideNativeSize) return;
  document.querySelectorAll('.pptx-page').forEach(page => {
    const sizer = page.querySelector('.pptx-slide-sizer');
    const slideEl = page.querySelector('.slide');
    if (!sizer || !slideEl) return;
    slideEl.style.transform = 'scale(1)';
    slideEl.style.transformOrigin = 'top left';
    sizer.style.width = `${pptxSlideNativeSize.width}px`;
    sizer.style.height = `${pptxSlideNativeSize.height}px`;
  });
}

function printDocument() { window.print(); }

window.addEventListener('beforeprint', () => {
  if (pptxSlideNativeSize) { updatePrintPageSize(); applyPptxPrintScale(); }
});
window.addEventListener('afterprint', () => {
  if (pptxSlideNativeSize) applyPptxSlideScale();
});

// ─── Zoom ─────────────────────────────────────────────────────────────────────

function updateZoom() {
  zoomLevelDisplay.textContent = `${currentZoom}%`;
  if (document.getElementById('pptx-slides-wrapper')) {
    applyPptxSlideScale();
    return;
  }
  const scale = currentZoom / 100;
  documentContainer.style.transform = `scale(${scale})`;
  documentContainer.style.transformOrigin = 'top center';
  documentContainer.style.width = currentZoom > 100 ? `${100 / scale}%` : '100%';
}

function applyPptxSlideScale() {
  if (!pptxSlideNativeSize) return;
  const pages = document.querySelectorAll('.pptx-page');
  const userScale = currentZoom / 100;
  pages.forEach(page => {
    const sizer = page.querySelector('.pptx-slide-sizer');
    const slideEl = page.querySelector('.slide');
    if (!sizer || !slideEl) return;
    const cellWidth = page.clientWidth - 80;
    const cellHeight = page.clientHeight - 48;
    const fitScale = Math.min(cellWidth / pptxSlideNativeSize.width, cellHeight / pptxSlideNativeSize.height, 1);
    const finalScale = fitScale * userScale;
    slideEl.style.transform = `scale(${finalScale})`;
    slideEl.style.transformOrigin = 'top left';
    sizer.style.width = `${pptxSlideNativeSize.width * finalScale}px`;
    sizer.style.height = `${pptxSlideNativeSize.height * finalScale}px`;
    const scaledWidth = pptxSlideNativeSize.width * finalScale;
    const scaledHeight = pptxSlideNativeSize.height * finalScale;
    page.classList.toggle('pptx-page-zoomed-overflow', scaledWidth > cellWidth || scaledHeight > cellHeight);
  });
}

window.addEventListener('resize', () => {
  if (document.getElementById('pptx-slides-wrapper')) applyPptxSlideScale();
});

function zoomIn()    { if (currentZoom < MAX_ZOOM) { currentZoom = Math.min(currentZoom + ZOOM_STEP, MAX_ZOOM); updateZoom(); } }
function zoomOut()   { if (currentZoom > MIN_ZOOM) { currentZoom = Math.max(currentZoom - ZOOM_STEP, MIN_ZOOM); updateZoom(); } }
function resetZoom() { currentZoom = 100; updateZoom(); }

// ─── DOCX renderer ────────────────────────────────────────────────────────────

async function renderDocx(arrayBuffer, filename) {
  if (typeof docx === 'undefined') throw new Error('Document rendering library not loaded.');
  await docx.renderAsync(arrayBuffer, documentContainer, null, {
    className: 'docx-viewer', inWrapper: true, ignoreWidth: false, ignoreHeight: false,
    ignoreFonts: false, breakPages: true, ignoreLastRenderedPageBreak: true,
    experimental: false, trimXmlDeclaration: true, debug: false
  });
  documentTitle.textContent = filename;
  document.title = `${filename} - Moodle Docs Viewer`;
  downloadBtn.disabled = false;
  printBtn.disabled = false;
  hideLoading();
}

// ─── Conversion server helper ─────────────────────────────────────────────────

async function convertViaServer(arrayBuffer, filename) {
  const { conversionServerUrl } = await browser.storage.local.get(['conversionServerUrl']);
  const serverUrl = (conversionServerUrl || '').trim().replace(/\/$/, '');
  if (!serverUrl) throw new Error('NO_SERVER');
  const response = await fetch(
    `${serverUrl}/convert?filename=${encodeURIComponent(filename)}`,
    { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: arrayBuffer }
  );
  if (!response.ok) {
    let detail = '';
    try { detail = (await response.json()).error || ''; } catch (_) {}
    throw new Error(`Conversion server error ${response.status}${detail ? ': ' + detail : ''}`);
  }
  return response.arrayBuffer();
}

function showLegacyFallback(filename, iconColor, reasonMsg) {
  hideLoading();
  documentContainer.innerHTML = `
    <div class="doc-fallback">
      <div class="doc-fallback-icon">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="1.5">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
          <polyline points="10 9 9 9 8 9"/>
        </svg>
      </div>
      <h2 class="doc-fallback-title">${filename}</h2>
      <p class="doc-fallback-msg">${reasonMsg}</p>
      <button class="btn btn-primary doc-fallback-download" id="legacy-fallback-download">
        Download to Open
      </button>
    </div>
  `;
  document.getElementById('legacy-fallback-download').addEventListener('click', downloadOriginalFile);
  documentTitle.textContent = filename;
  document.title = `${filename} - Moodle Docs Viewer`;
  downloadBtn.disabled = false;
}

// ─── DOC renderer ─────────────────────────────────────────────────────────────

async function renderDoc(arrayBuffer, filename) {
  try {
    const convertedBuffer = await convertViaServer(arrayBuffer, filename);
    return await renderDocx(convertedBuffer, filename);
  } catch (e) {
    if (e.message !== 'NO_SERVER') {
      showLegacyFallback(filename, '#2b579a',
        `Could not convert this file: ${e.message}<br>Download it to open in Word or LibreOffice.`);
      return;
    }
  }
  try {
    if (typeof docx === 'undefined') throw new Error('Document rendering library not loaded.');
    await docx.renderAsync(arrayBuffer, documentContainer, null, {
      className: 'docx-viewer', inWrapper: true, breakPages: true, trimXmlDeclaration: true
    });
    documentTitle.textContent = filename;
    document.title = `${filename} - Moodle Docs Viewer`;
    downloadBtn.disabled = false;
    printBtn.disabled = false;
    hideLoading();
  } catch (_) {
    showLegacyFallback(filename, '#2b579a',
      `Legacy Word (.doc) files cannot be rendered directly in the browser.<br>
       To enable in-browser viewing, set up a conversion server in <strong>Extension Settings</strong>.<br>
       Or download the file to open it in Word or LibreOffice.`);
  }
}

// ─── PPT renderer ─────────────────────────────────────────────────────────────

async function renderPpt(arrayBuffer, filename) {
  try {
    const convertedBuffer = await convertViaServer(arrayBuffer, filename);
    return await renderPptx(convertedBuffer, filename);
  } catch (e) {
    if (e.message !== 'NO_SERVER') {
      showLegacyFallback(filename, '#c55a11',
        `Could not convert this file: ${e.message}<br>Download it to open in PowerPoint or LibreOffice.`);
      return;
    }
  }
  showLegacyFallback(filename, '#c55a11',
    `Legacy PowerPoint (.ppt) files cannot be rendered directly in the browser.<br>
     To enable in-browser viewing, set up a conversion server in <strong>Extension Settings</strong>.<br>
     Or download the file to open it in PowerPoint or LibreOffice.`);
}

// ─── XLSX renderer ────────────────────────────────────────────────────────────

async function renderXlsx(arrayBuffer, filename) {
  if (typeof XLSX === 'undefined') throw new Error('Spreadsheet rendering library not loaded.');
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetNames = workbook.SheetNames;
  if (sheetNames.length === 0) throw new Error('This spreadsheet appears to be empty.');

  sheetTabsBar.hidden = false;
  sheetTabsBar.innerHTML = '';

  function renderSheet(name) {
    documentContainer.innerHTML = '';
    const ws = workbook.Sheets[name];
    const html = XLSX.utils.sheet_to_html(ws, { editable: false });
    const wrapper = document.createElement('div');
    wrapper.className = 'xlsx-wrapper';
    wrapper.innerHTML = html;
    documentContainer.appendChild(wrapper);
    const table = wrapper.querySelector('table');
    if (table) table.className = 'xlsx-table';
    sheetTabsBar.querySelectorAll('.sheet-tab').forEach(t => t.classList.remove('active'));
    const activeTab = sheetTabsBar.querySelector(`[data-sheet="${CSS.escape(name)}"]`);
    if (activeTab) activeTab.classList.add('active');
  }

  sheetNames.forEach((name, i) => {
    const tab = document.createElement('button');
    tab.className = 'sheet-tab' + (i === 0 ? ' active' : '');
    tab.textContent = name;
    tab.dataset.sheet = name;
    tab.addEventListener('click', () => renderSheet(name));
    sheetTabsBar.appendChild(tab);
  });

  renderSheet(sheetNames[0]);
  documentTitle.textContent = filename;
  document.title = `${filename} - Moodle Docs Viewer`;
  downloadBtn.disabled = false;
  printBtn.disabled = false;
  hideLoading();
}

// ─── PDF / Image renderer ──────────────────────────────────────────────────────

/**
 * Renders a PDF or image by building a fresh blob URL and injecting an
 * <iframe> (PDF) or <img> (image) into the document container.
 * The blob URL is revoked when the tab is closed (beforeunload) or a new
 * file is loaded (showLoading calls revokeObjectURL).
 */
async function renderNative(arrayBuffer, filename, docType, mimeType) {
  const mime = mimeType || (docType === 'pdf' ? 'application/pdf' : 'application/octet-stream');
  const blob = new Blob([arrayBuffer], { type: mime });
  nativeBlobUrl = URL.createObjectURL(blob);

  documentContainer.innerHTML = '';

  if (docType === 'pdf') {
    const iframe = document.createElement('iframe');
    iframe.className = 'native-frame';
    iframe.src = nativeBlobUrl;
    iframe.title = filename;
    documentContainer.appendChild(iframe);
  } else {
    // image
    const img = document.createElement('img');
    img.className = 'native-image';
    img.src = nativeBlobUrl;
    img.alt = filename;
    documentContainer.appendChild(img);
  }

  documentTitle.textContent = filename;
  document.title = `${filename} - Moodle Docs Viewer`;
  downloadBtn.disabled = false;
  printBtn.disabled = false;
  hideLoading();
  updateZoom();
}

window.addEventListener('beforeunload', () => {
  if (nativeBlobUrl) URL.revokeObjectURL(nativeBlobUrl);
});

// ─── PPTX renderer (PPTXjs) ───────────────────────────────────────────────────

let pptxjsLoadPromise = null;

function loadScriptSequential(src) {
  return new Promise((resolve, reject) => {
    const el = document.createElement('script');
    el.src = src;
    el.onload = () => resolve();
    el.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(el);
  });
}

function loadStylesheet(href) {
  if (document.querySelector(`link[href="${href}"]`)) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = href;
  document.head.appendChild(link);
}

function loadPptxJs() {
  if (pptxjsLoadPromise) return pptxjsLoadPromise;
  pptxjsLoadPromise = (async () => {
    const jsZipV3 = window.JSZip;
    loadStylesheet('lib/pptxjs/css/pptxjs.css');
    loadStylesheet('lib/pptxjs/css/nv.d3.min.css');
    const scripts = [
      'lib/pptxjs/js/jquery-1.11.3.min.js',
      'lib/pptxjs/js/jszip-v2.min.js',
      'lib/pptxjs/js/filereader.js',
      'lib/pptxjs/js/d3.min.js',
      'lib/pptxjs/js/nv.d3.min.js',
      'lib/pptxjs/js/dingbat.js',
      'lib/pptxjs/js/pptxjs.min.js'
    ];
    for (const src of scripts) {
      await loadScriptSequential(browser.runtime.getURL(src));
    }
    if (typeof jQuery === 'undefined' || typeof jQuery.fn.pptxToHtml === 'undefined') {
      throw new Error('Presentation rendering library failed to load.');
    }
    window.__pptxJsZipV2 = window.JSZip;
    window.__pptxJsZipV3 = jsZipV3;
  })();
  return pptxjsLoadPromise;
}

function waitForPptxRender(container, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const isDone = () => !container.querySelector('.slides-loadnig-msg');
    if (isDone() && container.querySelector('.slide')) { resolve(); return; }
    const observer = new MutationObserver(() => {
      if (isDone()) { observer.disconnect(); clearTimeout(timer); resolve(); }
    });
    observer.observe(container, { childList: true, subtree: true });
    const timer = setTimeout(() => { observer.disconnect(); reject(new Error('Timed out rendering the presentation.')); }, timeoutMs);
  });
}

function wrapSlidesForPaging(pptxResultEl) {
  const existing = document.getElementById('pptx-slides-wrapper');
  if (existing) existing.remove();
  const slideEls = Array.from(pptxResultEl.querySelectorAll(':scope > #all_slides_warpper > .slide, :scope > .slide'));
  const wrapper = document.createElement('div');
  wrapper.id = 'pptx-slides-wrapper';
  wrapper.className = 'pptx-slides-wrapper';
  slideEls.forEach((slideEl, i) => {
    const page = document.createElement('div');
    page.className = 'pptx-page';
    page.id = `pptx-page-${i}`;
    const sizer = document.createElement('div');
    sizer.className = 'pptx-slide-sizer';
    sizer.appendChild(slideEl);
    page.appendChild(sizer);
    wrapper.appendChild(page);
  });
  pptxResultEl.querySelectorAll(':scope > style').forEach(styleEl => wrapper.appendChild(styleEl));
  return { wrapper, count: slideEls.length };
}

function updateSlideNavUI(index) {
  currentSlideIndex = index;
  slideNumberInput.value = index + 1;
  slideTotalEl.textContent = slides.length;
  prevSlideBtn.disabled = index === 0;
  nextSlideBtn.disabled = index === slides.length - 1;
}

function goToSlide(index, animate = true) {
  if (index < 0 || index >= slides.length) return;
  const page = document.getElementById(`pptx-page-${index}`);
  if (page) {
    isProgrammaticSlideScroll = true;
    page.scrollIntoView({ behavior: animate ? 'smooth' : 'instant', block: 'start' });
    clearTimeout(goToSlide._settleTimer);
    goToSlide._settleTimer = setTimeout(() => { isProgrammaticSlideScroll = false; }, animate ? 600 : 50);
  }
  updateSlideNavUI(index);
}

function setupSlideScrollObserver(scrollRoot) {
  if (slideScrollObserver) { slideScrollObserver.disconnect(); slideScrollObserver = null; }
  const pages = Array.from(scrollRoot.querySelectorAll('.pptx-page'));
  if (pages.length === 0) return;
  const threshold = Array.from({ length: 21 }, (_, i) => i * 0.05);
  const ratios = new Map(pages.map(page => [page, 0]));
  slideScrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => ratios.set(entry.target, entry.intersectionRatio));
    if (isProgrammaticSlideScroll) return;
    let bestPage = null, bestRatio = 0;
    ratios.forEach((ratio, page) => { if (ratio > bestRatio) { bestRatio = ratio; bestPage = page; } });
    if (!bestPage) return;
    const index = pages.indexOf(bestPage);
    if (index === -1 || index === currentSlideIndex) return;
    updateSlideNavUI(index);
  }, { root: scrollRoot, threshold });
  pages.forEach(page => slideScrollObserver.observe(page));
}

function fixPptxTextRendering(container) {
  container.querySelectorAll('sapn.text-block').forEach(el => {
    el.style.removeProperty('width');
    el.style.removeProperty('min-width');
  });
  container.querySelectorAll('div.block.content').forEach(el => {
    el.style.removeProperty('height');
    el.style.removeProperty('min-height');
  });
  container.querySelectorAll('.slide-prgrph').forEach(el => {
    el.style.removeProperty('width');
    el.style.removeProperty('min-width');
  });
  container.querySelectorAll('.slide-prgrph > div').forEach(el => {
    if (el.style.direction === 'initial' || el.style.overflowWrap === 'break-word') {
      el.style.removeProperty('width');
      el.style.removeProperty('min-width');
    }
  });
  container.querySelectorAll('sapn.text-block').forEach(el => {
    el.childNodes.forEach(node => {
      if (node.nodeType === Node.TEXT_NODE) {
        node.textContent = node.textContent.replace(/\u00A0/g, ' ');
      }
    });
  });
  container.querySelectorAll('sapn.text-block').forEach(el => {
    const next = el.nextSibling;
    if (!next) return;
    if (next.nodeName.toLowerCase() !== 'sapn' || !next.classList.contains('text-block')) return;
    if (el.textContent.slice(-1) !== ' ' && next.textContent.charAt(0) !== ' ') {
      el.parentNode.insertBefore(document.createTextNode(' '), next);
    }
  });
}

async function renderPptx(arrayBuffer, filename) {
  const sig = new Uint8Array(arrayBuffer.slice(0, 2));
  if (sig[0] !== 0x50 || sig[1] !== 0x4b) return await renderPpt(arrayBuffer, filename);

  await loadPptxJs();

  const blob = new Blob([arrayBuffer], { type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' });
  const blobUrl = URL.createObjectURL(blob);

  documentContainer.hidden = true;
  const existingResult = document.getElementById('pptxjs-result');
  if (existingResult) existingResult.remove();

  const resultEl = document.createElement('div');
  resultEl.id = 'pptxjs-result';
  resultEl.style.cssText = 'position:absolute; left:-99999px; top:0; visibility:hidden;';
  documentContainer.parentElement.appendChild(resultEl);

  window.JSZip = window.__pptxJsZipV2;
  try {
    jQuery(resultEl).pptxToHtml({ pptxFileUrl: blobUrl, slideMode: false, keyBoardShortCut: false, mediaProcess: true, themeProcess: true });
    await waitForPptxRender(resultEl);
  } finally {
    if (window.__pptxJsZipV3) window.JSZip = window.__pptxJsZipV3;
    URL.revokeObjectURL(blobUrl);
  }

  const { wrapper, count } = wrapSlidesForPaging(resultEl);
  resultEl.remove();
  fixPptxTextRendering(wrapper);

  if (count === 0) throw new Error('No slides found in this presentation.');

  slides = new Array(count);
  currentSlideIndex = 0;

  const docWrapper = documentContainer.parentElement;
  docWrapper.appendChild(wrapper);
  docWrapper.classList.add('pptx-mode');

  const firstSlide = wrapper.querySelector('.pptx-page .slide');
  if (firstSlide) {
    const rect = firstSlide.getBoundingClientRect();
    pptxSlideNativeSize = { width: rect.width, height: rect.height };
  }

  slideNavBar.hidden = false;
  slideNumberInput.max = slides.length;
  slideTotalEl.textContent = slides.length;
  currentZoom = 100;
  zoomLevelDisplay.textContent = '100%';
  applyPptxSlideScale();
  updatePrintPageSize();
  goToSlide(0, false);
  setupSlideScrollObserver(docWrapper);

  documentTitle.textContent = filename;
  document.title = `${filename} - Moodle Docs Viewer`;
  downloadBtn.disabled = false;
  printBtn.disabled = false;
  hideLoading();
}

// ─── Dispatch ──────────────────────────────────────────────────────────────────

async function renderDocument(arrayBuffer, filename, docType, mimeType) {
  switch (docType) {
    case 'docx':  return await renderDocx(arrayBuffer, filename);
    case 'doc':   return await renderDoc(arrayBuffer, filename);
    case 'pptx':  return await renderPptx(arrayBuffer, filename);
    case 'ppt':   return await renderPpt(arrayBuffer, filename);
    case 'xlsx':  return await renderXlsx(arrayBuffer, filename);
    case 'pdf':
    case 'image': return await renderNative(arrayBuffer, filename, docType, mimeType);
    default:      throw new Error(`Unsupported document type: ${docType}`);
  }
}

// ─── Expiry ticker ────────────────────────────────────────────────────────────

let expiryTickInterval = null;

function startExpiryTick() {
  if (expiryTickInterval) clearInterval(expiryTickInterval);
  expiryTickInterval = setInterval(() => {
    if (currentDocument) updatePinUI();
  }, 60000);
}

async function loadDocument() {
  showLoading();

  const params = new URLSearchParams(window.location.search);
  currentDocKey = params.get('docKey');

  if (!currentDocKey) currentDocKey = 'tempDoc';

  try {
    const result = await browser.storage.local.get([currentDocKey]);
    const doc = result[currentDocKey];

    if (!doc || !doc.filename) {
      throw new Error('Document not found. It may have expired or been deleted.');
    }

    // Auto-delete expired unpinned documents instead of showing them
    if (!doc.pinned && doc.expiresAt && doc.expiresAt < Date.now()) {
      await DocStore.deleteDoc(currentDocKey);
      throw new Error('expired');
    }

    currentDocument = doc;

    const arrayBuffer = await DocBlobStore.getBlob(currentDocKey);
    if (!arrayBuffer) {
      throw new Error('Document data not found. It may have been deleted.');
    }

    const docType = currentDocument.docType || 'docx';

    await renderDocument(arrayBuffer, currentDocument.filename, docType, currentDocument.mimeType);

    // Touch on success — only updates lastOpenedAt, never resets expiry
    await DocStore.touchDoc(currentDocKey);
    const refreshed = await browser.storage.local.get([currentDocKey]);
    if (refreshed[currentDocKey]) currentDocument = refreshed[currentDocKey];

    updatePinUI();
    startExpiryTick();

  } catch (error) {
    console.error('Error loading document:', error);
    const msg = error.message || 'Failed to load document';
    const isExpiry = msg === 'expired' || msg.includes('expired') || msg.includes('not found');
    showError(isExpiry
      ? 'This document has expired and been deleted. Pin documents to keep them indefinitely.'
      : msg);
  }
}

// ─── Event listeners ──────────────────────────────────────────────────────────

downloadBtn.addEventListener('click', downloadOriginalFile);
printBtn.addEventListener('click', printDocument);
zoomInBtn.addEventListener('click', zoomIn);
zoomOutBtn.addEventListener('click', zoomOut);
zoomResetBtn.addEventListener('click', resetZoom);

prevSlideBtn.addEventListener('click', () => { if (currentSlideIndex > 0) goToSlide(currentSlideIndex - 1); });
nextSlideBtn.addEventListener('click', () => { if (currentSlideIndex < slides.length - 1) goToSlide(currentSlideIndex + 1); });

function commitSlideNumberInput() {
  const raw = slideNumberInput.value;
  let target = parseInt(raw, 10);
  if (Number.isNaN(target)) target = currentSlideIndex + 1;
  else target = Math.min(Math.max(target, 1), slides.length);
  slideNumberInput.value = target;
  if (target - 1 !== currentSlideIndex) goToSlide(target - 1);
}

slideNumberInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); commitSlideNumberInput(); slideNumberInput.blur(); }
  e.stopPropagation();
});
slideNumberInput.addEventListener('blur', commitSlideNumberInput);
slideNumberInput.addEventListener('keypress', (e) => e.stopPropagation());

downloadFallbackBtn.addEventListener('click', () => {
  if (currentDocument && currentDocument.url) window.open(currentDocument.url, '_blank');
  else downloadOriginalFile();
});
closeBtn.addEventListener('click', () => window.close());

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'p') { e.preventDefault(); if (!printBtn.disabled) printDocument(); }
  if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); if (!downloadBtn.disabled) downloadOriginalFile(); }
  if ((e.ctrlKey || e.metaKey) && (e.key === '=' || e.key === '+')) { e.preventDefault(); zoomIn(); }
  if ((e.ctrlKey || e.metaKey) && e.key === '-') { e.preventDefault(); zoomOut(); }
  if ((e.ctrlKey || e.metaKey) && e.key === '0') { e.preventDefault(); resetZoom(); }
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { if (slides.length > 0 && currentSlideIndex < slides.length - 1) goToSlide(currentSlideIndex + 1); }
  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { if (slides.length > 0 && currentSlideIndex > 0) goToSlide(currentSlideIndex - 1); }
  if (e.key === 'Escape') window.close();
});

document.addEventListener('DOMContentLoaded', loadDocument);
