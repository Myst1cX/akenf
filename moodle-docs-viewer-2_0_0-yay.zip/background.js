/**
 * Background service worker.
 *
 * Handles file fetching on behalf of content scripts (CORS bypass), and
 * runs a periodic alarm to clean up expired savedDoc_* records even when
 * the dropzone page is never opened.
 */

// ── Message handler ────────────────────────────────────────────────────────────

browser.runtime.onMessage.addListener((message, sender) => {
  if (message.type === 'FETCH_DOCUMENT') {
    return fetchDocument(message.url);
  }
});

async function fetchDocument(url) {
  try {
    const response = await fetch(url, {
      credentials: 'include',
      redirect: 'follow',
      headers: { 'Accept': '*/*' }
    });

    if (!response.ok) {
      return { error: `Failed to fetch: ${response.status} ${response.statusText}` };
    }

    const contentType        = response.headers.get('content-type') || '';
    const finalUrl           = response.url;
    const contentDisposition = response.headers.get('content-disposition') || '';
    const contentLength      = response.headers.get('content-length') || '';

    const arrayBuffer = await response.arrayBuffer();
    const dataArray   = Array.from(new Uint8Array(arrayBuffer));

    return { ok: true, dataArray, contentType, finalUrl, contentDisposition, contentLength };
  } catch (e) {
    return { error: e.message };
  }
}

// ── Alarm-based expiry sweep ───────────────────────────────────────────────────
//
// Inlined minimal version of DocStore.cleanupExpired() — service workers
// can't import the page-side doc-store.js module (different context/window).

async function cleanupExpiredDocs() {
  try {
    const all = await browser.storage.local.get(null);
    const now = Date.now();
    const toDelete = Object.entries(all)
      .filter(([key, val]) =>
        key.startsWith('savedDoc_') &&
        val &&
        !val.pinned &&
        val.expiresAt !== null &&
        val.expiresAt !== undefined &&
        val.expiresAt < now
      )
      .map(([key]) => key);

    if (toDelete.length > 0) {
      await browser.storage.local.remove(toDelete);
      console.log(`[background] Cleaned up ${toDelete.length} expired document(s).`);
    }
  } catch (e) {
    console.warn('[background] cleanupExpiredDocs failed (non-fatal):', e);
  }
}

/** Migrate any leftover tempDoc* keys from old extension versions. */
async function migrateLegacyKeys() {
  try {
    const all = await browser.storage.local.get(null);
    const legacy = Object.keys(all).filter(k => k === 'tempDoc' || k.startsWith('tempDoc_'));
    if (legacy.length > 0) {
      await browser.storage.local.remove(legacy);
      console.log(`[background] Migrated ${legacy.length} legacy tempDoc key(s).`);
    }
  } catch (e) {
    console.warn('[background] Legacy key migration failed (non-fatal):', e);
  }
}

browser.alarms.create('cleanupExpiredDocs', { periodInMinutes: 15 });

browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanupExpiredDocs') {
    cleanupExpiredDocs();
  }
});

// Run cleanup and migration on extension install / browser startup
browser.runtime.onInstalled.addListener(() => {
  migrateLegacyKeys();
  cleanupExpiredDocs();
});

browser.runtime.onStartup.addListener(() => {
  migrateLegacyKeys();
  cleanupExpiredDocs();
});
