const DEFAULT_SETTINGS = {
  maxFileSize: 20,
  enabled: true,
  conversionServerUrl: '',
  expiryMinutes: 60,
};

const PRESET_VALUES = [5, 20, 60, 0]; // minutes; 0 = never

const maxFileSizeInput         = document.getElementById('max-file-size');
const conversionServerUrlInput = document.getElementById('conversion-server-url');
const expiryPresetSelect       = document.getElementById('expiry-preset');
const expiryCustomRow          = document.getElementById('expiry-custom-row');
const expiryCustomValueInput   = document.getElementById('expiry-custom-value');
const expiryCustomUnitSelect   = document.getElementById('expiry-custom-unit');
const testServerBtn            = document.getElementById('test-server');
const testResultEl             = document.getElementById('test-result');
const saveBtn                  = document.getElementById('save-settings');
const resetBtn                 = document.getElementById('reset-defaults');
const statusMessage            = document.getElementById('status-message');
const ftDocStatus              = document.getElementById('ft-doc-status');
const ftPptStatus              = document.getElementById('ft-ppt-status');

function updateLegacyStatusBadges(url) {
  const active = url && url.trim().length > 0;
  const label = active ? 'Via conversion server' : 'Download only';
  ftDocStatus.textContent = label;
  ftPptStatus.textContent = label;
}

function updateCustomRowVisibility() {
  expiryCustomRow.hidden = expiryPresetSelect.value !== 'custom';
}

// Splits a total-minutes value into the largest whole unit (days > hours > minutes)
// so the custom row shows e.g. "7 / Days" instead of "10080 / Minutes".
function minutesToCustomFields(totalMinutes) {
  if (totalMinutes > 0 && totalMinutes % 1440 === 0) return { value: totalMinutes / 1440, unit: 1440 };
  if (totalMinutes > 0 && totalMinutes % 60 === 0)   return { value: totalMinutes / 60, unit: 60 };
  return { value: totalMinutes, unit: 1 };
}

async function loadSettings() {
  const result = await browser.storage.local.get(['maxFileSize', 'conversionServerUrl', 'expiryMinutes', 'expiryHours']);
  maxFileSizeInput.value = result.maxFileSize || DEFAULT_SETTINGS.maxFileSize;
  const url = result.conversionServerUrl || '';
  conversionServerUrlInput.value = url;
  updateLegacyStatusBadges(url);

  // expiryMinutes is the current setting; expiryHours is read as a fallback
  // for anyone upgrading from a version that stored expiry in whole hours.
  let expiryMinutes;
  if (result.expiryMinutes !== undefined && result.expiryMinutes !== null) {
    expiryMinutes = result.expiryMinutes;
  } else if (result.expiryHours !== undefined && result.expiryHours !== null) {
    expiryMinutes = result.expiryHours * 60;
  } else {
    expiryMinutes = DEFAULT_SETTINGS.expiryMinutes;
  }

  if (PRESET_VALUES.includes(expiryMinutes)) {
    expiryPresetSelect.value = String(expiryMinutes);
  } else {
    expiryPresetSelect.value = 'custom';
    const { value, unit } = minutesToCustomFields(expiryMinutes);
    expiryCustomValueInput.value = value;
    expiryCustomUnitSelect.value = String(unit);
  }
  updateCustomRowVisibility();
}

function getExpiryMinutesFromForm() {
  if (expiryPresetSelect.value !== 'custom') {
    return parseInt(expiryPresetSelect.value, 10);
  }
  const value = parseInt(expiryCustomValueInput.value, 10);
  const unit  = parseInt(expiryCustomUnitSelect.value, 10);
  if (isNaN(value) || value < 1) return null; // invalid
  return value * unit;
}

async function saveSettings() {
  const maxFileSize = parseInt(maxFileSizeInput.value, 10);
  if (isNaN(maxFileSize) || maxFileSize < 1 || maxFileSize > 50) {
    showStatus('File size limit must be between 1 and 50 MB', 'error');
    return;
  }

  const expiryMinutes = getExpiryMinutesFromForm();
  if (expiryMinutes === null) {
    showStatus('Enter a custom expiry of at least 1', 'error');
    return;
  }

  const conversionServerUrl = conversionServerUrlInput.value.trim().replace(/\/$/, '');

  await browser.storage.local.set({ maxFileSize, enabled: true, conversionServerUrl, expiryMinutes });
  await browser.storage.local.remove(['expiryHours']); // superseded by expiryMinutes
  updateLegacyStatusBadges(conversionServerUrl);
  showStatus('Settings saved!', 'success');
}

async function resetToDefaults() {
  await browser.storage.local.set(DEFAULT_SETTINGS);
  await browser.storage.local.remove(['expiryHours']);
  loadSettings();
  showStatus('Settings reset to defaults', 'success');
}

async function testServer() {
  const url = conversionServerUrlInput.value.trim().replace(/\/$/, '');
  if (!url) {
    testResultEl.textContent = 'Enter a server URL first.';
    testResultEl.style.color = 'var(--color-warning, #c55a11)';
    return;
  }
  testResultEl.textContent = 'Connecting…';
  testResultEl.style.color = 'inherit';
  try {
    const res = await fetch(`${url}/health`, { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      testResultEl.textContent = '✓ Server reachable and healthy';
      testResultEl.style.color = 'green';
    } else {
      testResultEl.textContent = `✗ Server returned ${res.status}`;
      testResultEl.style.color = 'red';
    }
  } catch (e) {
    testResultEl.textContent = `✗ Could not reach server: ${e.message}`;
    testResultEl.style.color = 'red';
  }
}

function showStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = `status-message ${type}`;
  statusMessage.hidden = false;
  setTimeout(() => { statusMessage.hidden = true; }, 3000);
}

saveBtn.addEventListener('click', saveSettings);
resetBtn.addEventListener('click', resetToDefaults);
testServerBtn.addEventListener('click', testServer);
maxFileSizeInput.addEventListener('keydown', e => { if (e.key === 'Enter') saveSettings(); });
expiryPresetSelect.addEventListener('change', updateCustomRowVisibility);

document.getElementById('open-dropzone-link').addEventListener('click', (e) => {
  e.preventDefault();
  browser.tabs.create({ url: browser.runtime.getURL('dropzone.html') });
});

document.getElementById('manage-library-link').addEventListener('click', (e) => {
  e.preventDefault();
  browser.tabs.create({ url: browser.runtime.getURL('library.html') });
});

loadSettings();
